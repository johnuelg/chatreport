import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Folder, Plus, MoreVertical, Pencil, Trash2, Loader2, Upload } from "lucide-react";
import { cn } from "@/lib/utils";

interface DocumentFolder {
  id: string;
  name: string;
  description: string | null;
  color: string;
}

interface FolderManagerProps {
  title?: string;
  domainId?: string | null;
  folders: DocumentFolder[];
  selectedFolderId: string | null;
  onSelectFolder: (folderId: string | null) => void;
  onFoldersChange: () => void;
  isAdmin: boolean;
  documentCounts: Record<string, number>;
  onAddData?: () => void;
}

const FOLDER_COLORS = [
  "#6366f1", // indigo
  "#8b5cf6", // violet
  "#ec4899", // pink
  "#f43f5e", // rose
  "#f97316", // orange
  "#eab308", // yellow
  "#22c55e", // green
  "#14b8a6", // teal
  "#0ea5e9", // sky
  "#64748b", // slate
];

export function FolderManager({
  title = "Folders",
  domainId = null,
  folders,
  selectedFolderId,
  onSelectFolder,
  onFoldersChange,
  isAdmin,
  documentCounts,
  onAddData,
}: FolderManagerProps) {
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingFolder, setEditingFolder] = useState<DocumentFolder | null>(null);
  const [folderName, setFolderName] = useState("");
  const [folderColor, setFolderColor] = useState(FOLDER_COLORS[0]);
  const [isSaving, setIsSaving] = useState(false);

  const handleCreateFolder = async () => {
    if (!folderName.trim()) return;
    if (!domainId) {
      toast.error("Select a domain first");
      return;
    }

    setIsSaving(true);
    try {
      const { error } = await supabase.from("document_folders").insert({
        name: folderName.trim(),
        color: folderColor,
        domain_id: domainId,
      });

      if (error) throw error;

      toast.success("Folder created");
      setCreateDialogOpen(false);
      setFolderName("");
      setFolderColor(FOLDER_COLORS[0]);
      onFoldersChange();
    } catch (error) {
      console.error("Create folder error:", error);
      toast.error("Failed to create folder");
    } finally {
      setIsSaving(false);
    }
  };

  const handleUpdateFolder = async () => {
    if (!editingFolder || !folderName.trim()) return;

    setIsSaving(true);
    try {
      const { error } = await supabase
        .from("document_folders")
        .update({
          name: folderName.trim(),
          color: folderColor,
        })
        .eq("id", editingFolder.id);

      if (error) throw error;

      toast.success("Folder updated");
      setEditDialogOpen(false);
      setEditingFolder(null);
      setFolderName("");
      onFoldersChange();
    } catch (error) {
      console.error("Update folder error:", error);
      toast.error("Failed to update folder");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteFolder = async (folder: DocumentFolder) => {
    try {
      const { error } = await supabase
        .from("document_folders")
        .delete()
        .eq("id", folder.id);

      if (error) throw error;

      toast.success("Folder deleted");
      if (selectedFolderId === folder.id) {
        onSelectFolder(null);
      }
      onFoldersChange();
    } catch (error) {
      console.error("Delete folder error:", error);
      toast.error("Failed to delete folder");
    }
  };

  const openEditDialog = (folder: DocumentFolder) => {
    setEditingFolder(folder);
    setFolderName(folder.name);
    setFolderColor(folder.color);
    setEditDialogOpen(true);
  };

  const totalDocuments = Object.values(documentCounts).reduce((a, b) => a + b, 0);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
        {isAdmin && (
          <div className="flex items-center gap-1">
            {onAddData && (
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={onAddData}
                title="Add Data"
              >
                <Upload className="h-4 w-4" />
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={() => setCreateDialogOpen(true)}
              disabled={!domainId}
              title={domainId ? "Add Folder" : "Select a domain to add folders"}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>

      {/* All Documents */}
      <button
        onClick={() => onSelectFolder(null)}
        className={cn(
          "w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors",
          selectedFolderId === null
            ? "bg-primary text-primary-foreground"
            : "hover:bg-muted"
        )}
      >
        <Folder className="h-4 w-4" />
        <span className="flex-1 text-left">All Documents</span>
        <span className="text-xs opacity-70">{totalDocuments}</span>
      </button>

      {/* Folder list */}
      {folders.map((folder) => (
        <div
          key={folder.id}
          className={cn(
            "group flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors",
            selectedFolderId === folder.id
              ? "bg-primary text-primary-foreground"
              : "hover:bg-muted"
          )}
        >
          <button
            onClick={() => onSelectFolder(folder.id)}
            className="flex items-center gap-2 flex-1 min-w-0"
          >
            <Folder className="h-4 w-4 shrink-0" style={{ color: folder.color }} />
            <span className="flex-1 text-left truncate">{folder.name}</span>
            <span className="text-xs opacity-70">
              {documentCounts[folder.id] || 0}
            </span>
          </button>
          {isAdmin && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <MoreVertical className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => openEditDialog(folder)}>
                  <Pencil className="h-4 w-4 mr-2" />
                  Rename
                </DropdownMenuItem>
                <DropdownMenuItem
                  className="text-destructive"
                  onClick={() => handleDeleteFolder(folder)}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      ))}

      {/* Create Folder Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create Folder</DialogTitle>
            <DialogDescription>
              Create a new folder to organize your documents
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="folderName">Folder Name</Label>
              <Input
                id="folderName"
                value={folderName}
                onChange={(e) => setFolderName(e.target.value)}
                placeholder="Enter folder name..."
              />
            </div>
            <div className="space-y-2">
              <Label>Color</Label>
              <div className="flex gap-2 flex-wrap">
                {FOLDER_COLORS.map((color) => (
                  <button
                    key={color}
                    onClick={() => setFolderColor(color)}
                    className={cn(
                      "w-8 h-8 rounded-full transition-all",
                      folderColor === color && "ring-2 ring-offset-2 ring-primary"
                    )}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleCreateFolder}
              disabled={!folderName.trim() || isSaving}
            >
              {isSaving ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                "Create"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Folder Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Folder</DialogTitle>
            <DialogDescription>Update folder name and color</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="editFolderName">Folder Name</Label>
              <Input
                id="editFolderName"
                value={folderName}
                onChange={(e) => setFolderName(e.target.value)}
                placeholder="Enter folder name..."
              />
            </div>
            <div className="space-y-2">
              <Label>Color</Label>
              <div className="flex gap-2 flex-wrap">
                {FOLDER_COLORS.map((color) => (
                  <button
                    key={color}
                    onClick={() => setFolderColor(color)}
                    className={cn(
                      "w-8 h-8 rounded-full transition-all",
                      folderColor === color && "ring-2 ring-offset-2 ring-primary"
                    )}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleUpdateFolder}
              disabled={!folderName.trim() || isSaving}
            >
              {isSaving ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                "Save"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
