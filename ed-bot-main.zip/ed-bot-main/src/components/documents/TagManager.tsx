import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Tag, Plus, X, Loader2, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

interface DocumentTag {
  id: string;
  name: string;
  color: string;
}

interface TagManagerProps {
  documentId: string;
  assignedTags: DocumentTag[];
  allTags: DocumentTag[];
  onTagsChange: () => void;
  isAdmin: boolean;
}

const TAG_COLORS = [
  "#ef4444", // red
  "#f97316", // orange
  "#eab308", // yellow
  "#22c55e", // green
  "#14b8a6", // teal
  "#0ea5e9", // sky
  "#6366f1", // indigo
  "#8b5cf6", // violet
  "#ec4899", // pink
  "#64748b", // slate
];

export function TagManager({
  documentId,
  assignedTags,
  allTags,
  onTagsChange,
  isAdmin,
}: TagManagerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [newTagName, setNewTagName] = useState("");
  const [newTagColor, setNewTagColor] = useState(TAG_COLORS[0]);
  const [isCreating, setIsCreating] = useState(false);
  const [showNewTagForm, setShowNewTagForm] = useState(false);

  const handleToggleTag = async (tag: DocumentTag) => {
    const isAssigned = assignedTags.some((t) => t.id === tag.id);

    try {
      if (isAssigned) {
        const { error } = await supabase
          .from("document_tag_assignments")
          .delete()
          .eq("document_id", documentId)
          .eq("tag_id", tag.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("document_tag_assignments")
          .insert({ document_id: documentId, tag_id: tag.id });

        if (error) throw error;
      }

      onTagsChange();
    } catch (error) {
      console.error("Tag toggle error:", error);
      toast.error("Failed to update tags");
    }
  };

  const handleCreateTag = async () => {
    if (!newTagName.trim()) return;

    setIsCreating(true);
    try {
      const { data, error } = await supabase
        .from("document_tags")
        .insert({ name: newTagName.trim(), color: newTagColor })
        .select()
        .single();

      if (error) throw error;

      // Assign the new tag to the document
      await supabase
        .from("document_tag_assignments")
        .insert({ document_id: documentId, tag_id: data.id });

      toast.success("Tag created and assigned");
      setNewTagName("");
      setShowNewTagForm(false);
      onTagsChange();
    } catch (error: any) {
      console.error("Create tag error:", error);
      if (error.code === "23505") {
        toast.error("A tag with this name already exists");
      } else {
        toast.error("Failed to create tag");
      }
    } finally {
      setIsCreating(false);
    }
  };

  if (!isAdmin) {
    return (
      <div className="flex flex-wrap gap-1">
        {assignedTags.map((tag) => (
          <Badge
            key={tag.id}
            variant="outline"
            className="text-xs"
            style={{ borderColor: tag.color, color: tag.color }}
          >
            {tag.name}
          </Badge>
        ))}
      </div>
    );
  }

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="h-7 px-2 gap-1">
          <Tag className="h-3 w-3" />
          {assignedTags.length > 0 && (
            <span className="text-xs">{assignedTags.length}</span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64 p-3" align="start">
        <div className="space-y-3">
          <div className="text-sm font-medium">Manage Tags</div>

          {/* Existing tags */}
          <div className="space-y-1 max-h-40 overflow-y-auto">
            {allTags.map((tag) => {
              const isAssigned = assignedTags.some((t) => t.id === tag.id);
              return (
                <button
                  key={tag.id}
                  onClick={() => handleToggleTag(tag)}
                  className={cn(
                    "w-full flex items-center gap-2 px-2 py-1.5 rounded text-sm transition-colors",
                    isAssigned ? "bg-primary/10" : "hover:bg-muted"
                  )}
                >
                  <div
                    className="w-3 h-3 rounded-full shrink-0"
                    style={{ backgroundColor: tag.color }}
                  />
                  <span className="flex-1 text-left truncate">{tag.name}</span>
                  {isAssigned && <Check className="h-4 w-4 text-primary" />}
                </button>
              );
            })}
            {allTags.length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-2">
                No tags yet
              </p>
            )}
          </div>

          {/* Create new tag */}
          {showNewTagForm ? (
            <div className="space-y-2 pt-2 border-t">
              <Input
                placeholder="Tag name..."
                value={newTagName}
                onChange={(e) => setNewTagName(e.target.value)}
                className="h-8 text-sm"
              />
              <div className="flex gap-1 flex-wrap">
                {TAG_COLORS.map((color) => (
                  <button
                    key={color}
                    onClick={() => setNewTagColor(color)}
                    className={cn(
                      "w-5 h-5 rounded-full transition-all",
                      newTagColor === color && "ring-2 ring-offset-1 ring-primary"
                    )}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  className="flex-1 h-7"
                  onClick={handleCreateTag}
                  disabled={!newTagName.trim() || isCreating}
                >
                  {isCreating ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    "Create"
                  )}
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7"
                  onClick={() => {
                    setShowNewTagForm(false);
                    setNewTagName("");
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <Button
              size="sm"
              variant="outline"
              className="w-full h-7"
              onClick={() => setShowNewTagForm(true)}
            >
              <Plus className="h-3 w-3 mr-1" />
              New Tag
            </Button>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}

// Display component for showing tags
interface TagDisplayProps {
  tags: DocumentTag[];
}

export function TagDisplay({ tags }: TagDisplayProps) {
  if (tags.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-1 mt-2">
      {tags.slice(0, 3).map((tag) => (
        <Badge
          key={tag.id}
          variant="outline"
          className="text-xs px-1.5 py-0"
          style={{ borderColor: tag.color, color: tag.color }}
        >
          {tag.name}
        </Badge>
      ))}
      {tags.length > 3 && (
        <Badge variant="outline" className="text-xs px-1.5 py-0">
          +{tags.length - 3}
        </Badge>
      )}
    </div>
  );
}

// Tag filter component for sidebar
interface TagFilterProps {
  tags: DocumentTag[];
  selectedTagIds: string[];
  onToggleTag: (tagId: string) => void;
}

export function TagFilter({ tags, selectedTagIds, onToggleTag }: TagFilterProps) {
  if (tags.length === 0) return null;

  return (
    <div className="space-y-2 pt-4 border-t">
      <h3 className="text-sm font-medium text-muted-foreground">Filter by Tags</h3>
      <div className="flex flex-wrap gap-1">
        {tags.map((tag) => {
          const isSelected = selectedTagIds.includes(tag.id);
          return (
            <button
              key={tag.id}
              onClick={() => onToggleTag(tag.id)}
              className={cn(
                "px-2 py-1 rounded-full text-xs transition-all",
                isSelected
                  ? "ring-2 ring-offset-1"
                  : "opacity-60 hover:opacity-100"
              )}
              style={{
                backgroundColor: isSelected ? tag.color : `${tag.color}20`,
                color: isSelected ? "white" : tag.color,
                ...(isSelected && { ringColor: tag.color }),
              }}
            >
              {tag.name}
            </button>
          );
        })}
      </div>
      {selectedTagIds.length > 0 && (
        <Button
          variant="ghost"
          size="sm"
          className="h-6 text-xs"
          onClick={() => selectedTagIds.forEach(onToggleTag)}
        >
          Clear filters
        </Button>
      )}
    </div>
  );
}
