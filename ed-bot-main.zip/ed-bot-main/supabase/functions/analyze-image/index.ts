import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

// Input validation schema
const analyzeImageSchema = z.object({
  documentId: z.string().uuid("Invalid document ID format"),
  filePath: z.string()
    .min(1, "File path is required")
    .max(500, "File path too long")
    .refine(
      (path) => !path.includes("..") && !path.includes("//"),
      "Invalid file path - path traversal not allowed"
    ),
  fileType: z.string()
    .optional()
    .refine(
      (type) => !type || ["image/png", "image/jpeg", "image/gif", "image/webp", "image/bmp"].includes(type),
      "Unsupported image type"
    )
});

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY")!;
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    // Verify user authentication
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      console.error("No authorization header provided");
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create client with user's auth context
    const supabaseClient = createClient(supabaseUrl, supabaseServiceKey, {
      global: { headers: { Authorization: authHeader } }
    });

    // Verify user token and get user
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);
    
    if (authError || !user) {
      console.error("Invalid authentication:", authError?.message);
      return new Response(
        JSON.stringify({ error: "Invalid authentication" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify user has admin role
    const { data: roleData } = await supabaseClient
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .single();

    if (roleData?.role !== "admin") {
      console.error("User lacks admin role:", user.id);
      return new Response(
        JSON.stringify({ error: "Insufficient permissions. Admin role required." }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Parse and validate request body
    const body = await req.json();
    const validationResult = analyzeImageSchema.safeParse(body);
    
    if (!validationResult.success) {
      console.error("Validation error:", validationResult.error.errors);
      return new Response(
        JSON.stringify({ 
          error: "Invalid request", 
          details: validationResult.error.errors.map(e => e.message).join(", ") 
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    const { documentId, filePath, fileType } = validationResult.data;
    
    console.log("Analyzing image:", { documentId, filePath, fileType, userId: user.id });

    // Use service role client for storage and database operations
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Verify document exists
    const { data: docCheck } = await supabase
      .from("documents")
      .select("id")
      .eq("id", documentId)
      .single();

    if (!docCheck) {
      return new Response(
        JSON.stringify({ error: "Document not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Download the image from storage
    const { data: fileData, error: downloadError } = await supabase.storage
      .from("documents")
      .download(filePath);

    if (downloadError) {
      console.error("Download error:", downloadError);
      throw new Error(`Failed to download file: ${downloadError.message}`);
    }

    // Convert image to base64
    const arrayBuffer = await fileData.arrayBuffer();
    const base64Image = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)));
    
    // Determine MIME type
    const mimeType = fileType || "image/png";
    const imageDataUrl = `data:${mimeType};base64,${base64Image}`;

    console.log("Sending image to AI for analysis...");

    // Use Lovable AI (Gemini) for vision analysis
    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content: `You are a data extraction assistant for Taif Children's Hospital Emergency Room Department. 
Your task is to extract ALL data, statistics, numbers, and text from medical reports and charts.
Output the extracted data in a structured, readable format.
Include:
- All numerical data and statistics
- Column headers and row labels from tables
- Dates and time periods
- Any text labels, titles, or annotations
- Categories and their associated values
Be thorough and extract everything visible in the image.`
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Please extract all data, statistics, and text from this ER/ED report image. Include all numbers, categories, dates, and any other relevant information you can see."
              },
              {
                type: "image_url",
                image_url: {
                  url: imageDataUrl
                }
              }
            ]
          }
        ]
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI API error:", response.status, errorText);
      
      if (response.status === 429) {
        throw new Error("Rate limit exceeded. Please try again later.");
      }
      if (response.status === 402) {
        throw new Error("AI credits exhausted. Please add credits to continue.");
      }
      
      throw new Error(`AI service error: ${response.status}`);
    }

    const aiResponse = await response.json();
    const extractedContent = aiResponse.choices?.[0]?.message?.content || "";

    console.log("Extracted content length:", extractedContent.length);
    console.log("Content preview:", extractedContent.substring(0, 200));

    // Update the document record with extracted content using secure RPC
    const { error: updateError } = await supabase
      .rpc("update_document_content", { 
        _document_id: documentId, 
        _content: extractedContent 
      });

    if (updateError) {
      console.error("Update error:", updateError);
      throw new Error(`Failed to update document: ${updateError.message}`);
    }

    console.log("Image analyzed successfully");

    return new Response(
      JSON.stringify({ 
        success: true, 
        contentLength: extractedContent.length,
        preview: extractedContent.substring(0, 300)
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Analysis error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
