import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.89.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface UpdateUserRequest {
  userId: string;
  email?: string;
  fullName?: string;
  role?: string;
  domainIds?: string[];
  newPassword?: string; // Admin reset password
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";

    if (!supabaseUrl || !serviceRoleKey || !anonKey) {
      console.error("Missing required backend env vars");
      return new Response(
        JSON.stringify({ error: "Server misconfiguration" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Service role client for admin operations + DB writes
    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    // Verify the requesting user token (DO NOT rely on server session in functions)
    const authHeader = req.headers.get("authorization") ?? req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      console.error("Missing or invalid authorization header");
      return new Response(
        JSON.stringify({ error: "No authorization header" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const token = authHeader.replace("Bearer ", "").trim();
    if (!token) {
      console.error("Empty bearer token");
      return new Response(
        JSON.stringify({ error: "Invalid token" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Use an anon client to validate the access token (official pattern)
    const supabaseAuth = createClient(supabaseUrl, anonKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    const {
      data: { user: requestingUser },
      error: authError,
    } = await supabaseAuth.auth.getUser(token);

    if (authError || !requestingUser) {
      console.error("Auth error:", authError);
      return new Response(
        JSON.stringify({ error: "Invalid token" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Requesting user:", requestingUser.id);

    // Check if requesting user is an admin
    const { data: roleData, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", requestingUser.id)
      .single();

    if (roleError || roleData?.role !== "admin") {
      return new Response(
        JSON.stringify({ error: "Unauthorized: Admin access required" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Parse request body
    const { userId, email, fullName, role, domainIds, newPassword }: UpdateUserRequest = await req.json();

    // Validate input
    if (!userId) {
      return new Response(
        JSON.stringify({ error: "Missing required field: userId" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Update auth user if email or password is provided
    if (email || newPassword) {
      const updateData: { email?: string; password?: string } = {};
      if (email) updateData.email = email;
      if (newPassword) {
        if (newPassword.length < 6) {
          return new Response(
            JSON.stringify({ error: "Password must be at least 6 characters" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        updateData.password = newPassword;
      }

      const { error: updateAuthError } = await supabaseAdmin.auth.admin.updateUserById(
        userId,
        updateData
      );

      if (updateAuthError) {
        console.error("Error updating auth user:", updateAuthError);
        // Check for duplicate email error
        if (updateAuthError.message?.includes("duplicate key") || 
            updateAuthError.message?.includes("already been registered") ||
            updateAuthError.code === "email_exists") {
          return new Response(
            JSON.stringify({ error: "This email is already registered to another user" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        return new Response(
          JSON.stringify({ error: updateAuthError.message }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      if (newPassword) {
        console.log("Password reset successfully for user:", userId);
      }
    }

    // Update profile if fullName or email is provided
    if (fullName || email) {
      const profileUpdate: Record<string, string | null> = {};
      if (fullName) profileUpdate.full_name = fullName;
      if (email) profileUpdate.email = email;

      const { error: profileError } = await supabaseAdmin
        .from("profiles")
        .update(profileUpdate)
        .eq("user_id", userId);

      if (profileError) {
        console.error("Error updating profile:", profileError);
        // Don't fail the whole request, continue
      }
    }

    // Update role if provided
    if (role) {
      // Validate role exists in the roles table
      const { data: validRole, error: validRoleError } = await supabaseAdmin
        .from("roles")
        .select("slug")
        .eq("slug", role)
        .maybeSingle();

      if (validRoleError || !validRole) {
        console.error("Invalid role:", role, validRoleError);
        return new Response(
          JSON.stringify({ error: `Invalid role: ${role}` }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const { data: existingRole } = await supabaseAdmin
        .from("user_roles")
        .select("id")
        .eq("user_id", userId)
        .maybeSingle();

      if (existingRole) {
        const { error: roleUpdateError } = await supabaseAdmin
          .from("user_roles")
          .update({ role })
          .eq("user_id", userId);

        if (roleUpdateError) {
          console.error("Error updating role:", roleUpdateError);
        }
      } else {
        const { error: roleInsertError } = await supabaseAdmin
          .from("user_roles")
          .insert({ user_id: userId, role });

        if (roleInsertError) {
          console.error("Error inserting role:", roleInsertError);
        }
      }
    }

    // Update user domains if provided
    if (domainIds !== undefined) {
      // First delete all existing user domains
      const { error: deleteDomainsError } = await supabaseAdmin
        .from("user_domains")
        .delete()
        .eq("user_id", userId);

      if (deleteDomainsError) {
        console.error("Error deleting user domains:", deleteDomainsError);
      }

      // Then insert new domains if any
      if (domainIds.length > 0) {
        const domainInserts = domainIds.map((domainId) => ({
          user_id: userId,
          domain_id: domainId,
        }));

        const { error: insertDomainsError } = await supabaseAdmin
          .from("user_domains")
          .insert(domainInserts);

        if (insertDomainsError) {
          console.error("Error inserting user domains:", insertDomainsError);
        }
      }
    }

    console.log("User updated successfully:", userId);

    return new Response(
      JSON.stringify({
        success: true,
        message: "User updated successfully",
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error: any) {
    console.error("Error in admin-update-user function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
};

serve(handler);