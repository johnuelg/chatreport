import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { ZipReader, BlobReader, TextWriter } from "https://deno.land/x/zipjs@v2.7.32/index.js";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

// Input validation schema
const parseDocumentSchema = z.object({
  documentId: z.string().uuid("Invalid document ID format"),
  filePath: z.string()
    .min(1, "File path is required")
    .max(500, "File path too long")
    .refine(
      (path) => !path.includes("..") && !path.includes("//"),
      "Invalid file path - path traversal not allowed"
    ),
  fileType: z.enum([
    "text/csv",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-excel",
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/msword"
  ], { errorMap: () => ({ message: "Unsupported file type" }) })
});

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Lightweight Excel text extraction from XLSX (which is a ZIP file)
async function extractExcelContent(fileData: Blob): Promise<string> {
  try {
    const zipReader = new ZipReader(new BlobReader(fileData));
    const entries = await zipReader.getEntries();
    
    let allContent = "";
    
    // Find shared strings file (contains cell text values)
    const sharedStringsEntry = entries.find(e => e.filename === "xl/sharedStrings.xml");
    const sharedStrings: string[] = [];
    
    if (sharedStringsEntry) {
      const textWriter = new TextWriter();
      const content = await sharedStringsEntry.getData!(textWriter);
      // Extract text from <t> tags
      const matches = content.match(/<t[^>]*>([^<]*)<\/t>/g) || [];
      for (const match of matches) {
        const text = match.replace(/<[^>]+>/g, "").trim();
        if (text) sharedStrings.push(text);
      }
    }
    
    // Find sheet files and extract content
    const sheetEntries = entries.filter(e => e.filename.startsWith("xl/worksheets/sheet"));
    
    for (const sheetEntry of sheetEntries) {
      const textWriter = new TextWriter();
      const content = await sheetEntry.getData!(textWriter);
      
      // Extract cell values - look for <v> tags (values) and <t> inline text
      const valueMatches = content.match(/<v>([^<]*)<\/v>/g) || [];
      const inlineMatches = content.match(/<t[^>]*>([^<]*)<\/t>/g) || [];
      
      const sheetContent: string[] = [];
      
      // Process values (may be indices into shared strings or direct values)
      for (const match of valueMatches) {
        const value = match.replace(/<[^>]+>/g, "").trim();
        const numVal = parseInt(value);
        // If it's a shared string index and we have shared strings
        if (!isNaN(numVal) && numVal < sharedStrings.length && sharedStrings.length > 0) {
          sheetContent.push(sharedStrings[numVal]);
        } else if (value) {
          sheetContent.push(value);
        }
      }
      
      // Add inline text
      for (const match of inlineMatches) {
        const text = match.replace(/<[^>]+>/g, "").trim();
        if (text) sheetContent.push(text);
      }
      
      if (sheetContent.length > 0) {
        allContent += sheetContent.join(", ") + "\n";
      }
    }
    
    await zipReader.close();
    return allContent || "No text content found in Excel file";
  } catch (error) {
    console.error("Excel extraction error:", error);
    return "Failed to extract Excel content";
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    
    // Verify user authentication
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      console.error("No authorization header provided");
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create client with user's auth context
    const supabaseClient = createClient(supabaseUrl, supabaseServiceKey, {
      global: { headers: { Authorization: authHeader } }
    });

    // Verify user token and get user
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);
    
    if (authError || !user) {
      console.error("Invalid authentication:", authError?.message);
      return new Response(
        JSON.stringify({ error: "Invalid authentication" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify user has admin role
    const { data: roleData } = await supabaseClient
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .single();

    if (roleData?.role !== "admin") {
      console.error("User lacks admin role:", user.id);
      return new Response(
        JSON.stringify({ error: "Insufficient permissions. Admin role required." }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Parse and validate request body
    const body = await req.json();
    const validationResult = parseDocumentSchema.safeParse(body);
    
    if (!validationResult.success) {
      console.error("Validation error:", validationResult.error.errors);
      return new Response(
        JSON.stringify({ 
          error: "Invalid request", 
          details: validationResult.error.errors.map(e => e.message).join(", ") 
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    const { documentId, filePath, fileType } = validationResult.data;
    
    console.log("Parsing document:", { documentId, filePath, fileType, userId: user.id });

    // Use service role client for storage and database operations
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Verify document exists
    const { data: docCheck } = await supabase
      .from("documents")
      .select("id")
      .eq("id", documentId)
      .single();

    if (!docCheck) {
      return new Response(
        JSON.stringify({ error: "Document not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Download the file from storage
    const { data: fileData, error: downloadError } = await supabase.storage
      .from("documents")
      .download(filePath);

    if (downloadError) {
      console.error("Download error:", downloadError);
      throw new Error(`Failed to download file: ${downloadError.message}`);
    }

    let extractedContent = "";

    // Extract text based on file type
    if (fileType === "text/csv") {
      // CSV: Read as text directly
      extractedContent = await fileData.text();
      console.log("Extracted CSV content, length:", extractedContent.length);
    } else if (
      fileType === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
      fileType === "application/vnd.ms-excel"
    ) {
      // Excel files: Use lightweight ZIP-based extraction
      extractedContent = await extractExcelContent(fileData);
      console.log("Extracted Excel content, length:", extractedContent.length);
    } else if (fileType === "application/pdf") {
      // PDF: Use pdf-parse equivalent for Deno
      // For now, we'll extract basic text using a simple approach
      const arrayBuffer = await fileData.arrayBuffer();
      const bytes = new Uint8Array(arrayBuffer);
      
      // Simple PDF text extraction (looks for text streams)
      const decoder = new TextDecoder("utf-8", { fatal: false });
      const pdfString = decoder.decode(bytes);
      
      // Extract text between BT and ET markers (basic text extraction)
      const textMatches = pdfString.match(/\(([^)]+)\)/g);
      if (textMatches) {
        extractedContent = textMatches
          .map(match => match.slice(1, -1))
          .filter(text => text.length > 1 && !/^[\\\/\d\s]+$/.test(text))
          .join(" ");
      }
      
      // If basic extraction failed, try to get any readable text
      if (!extractedContent || extractedContent.length < 50) {
        const readableText = pdfString
          .replace(/[^\x20-\x7E\n\r\t]/g, " ")
          .replace(/\s+/g, " ")
          .trim();
        extractedContent = readableText.substring(0, 50000); // Limit size
      }
      
      console.log("Extracted PDF content, length:", extractedContent.length);
    } else if (
      fileType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
      fileType === "application/msword"
    ) {
      // Word documents: Extract text from XML content
      const arrayBuffer = await fileData.arrayBuffer();
      const bytes = new Uint8Array(arrayBuffer);
      const decoder = new TextDecoder("utf-8", { fatal: false });
      const content = decoder.decode(bytes);
      
      // For DOCX, try to find text content
      const textMatches = content.match(/<w:t[^>]*>([^<]+)<\/w:t>/g);
      if (textMatches) {
        extractedContent = textMatches
          .map(match => match.replace(/<[^>]+>/g, ""))
          .join(" ");
      }
      
      console.log("Extracted Word content, length:", extractedContent.length);
    }

    // Clean up the extracted content - remove invalid Unicode and control characters
    // Use a function to sanitize character by character for maximum safety
    const sanitizeForPostgres = (text: string): string => {
      let result = "";
      for (let i = 0; i < text.length; i++) {
        const charCode = text.charCodeAt(i);
        // Skip null bytes and control characters (except tab, newline, carriage return)
        if (charCode === 0) continue; // Null byte - skip completely
        if (charCode < 32 && charCode !== 9 && charCode !== 10 && charCode !== 13) continue;
        if (charCode === 127) continue; // DEL character
        // Skip surrogate pairs that are incomplete
        if (charCode >= 0xD800 && charCode <= 0xDFFF) continue;
        result += text[i];
      }
      return result;
    };
    
    extractedContent = sanitizeForPostgres(extractedContent)
      // Replace multiple spaces/newlines with single space
      .replace(/\s+/g, " ")
      .trim()
      .substring(0, 100000); // Limit to 100k characters

    // Update the document record with extracted content using secure RPC
    const { error: updateError } = await supabase
      .rpc("update_document_content", { 
        _document_id: documentId, 
        _content: extractedContent 
      });

    if (updateError) {
      console.error("Update error:", updateError);
      throw new Error(`Failed to update document: ${updateError.message}`);
    }

    console.log("Document parsed successfully, content length:", extractedContent.length);

    return new Response(
      JSON.stringify({ 
        success: true, 
        contentLength: extractedContent.length,
        preview: extractedContent.substring(0, 200)
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Parse error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
