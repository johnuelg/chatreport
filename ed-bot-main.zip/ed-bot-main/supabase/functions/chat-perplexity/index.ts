import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient, SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

// Input validation schema
const MAX_MESSAGE_LENGTH = 10000;
const MAX_MESSAGES = 50;

const messageSchema = z.object({
  role: z.enum(["user", "assistant", "system"]),
  content: z.string().max(MAX_MESSAGE_LENGTH, `Message content exceeds ${MAX_MESSAGE_LENGTH} characters`)
});

const chatRequestSchema = z.object({
  messages: z.array(messageSchema)
    .min(1, "At least one message is required")
    .max(MAX_MESSAGES, `Maximum ${MAX_MESSAGES} messages allowed`),
  language: z.enum(["en", "ar"]).optional().default("en")
});

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface Document {
  name: string;
  content: string | null;
  description: string | null;
  category: string | null;
}

interface ScoredDocument extends Document {
  score: number;
}

// Category keywords mapping for better matching
const CATEGORY_KEYWORDS: Record<string, string[]> = {
  ED: ["ed", "emergency", "emergency department", "er", "emergency room"],
  BB: ["bb", "blood bank", "blood"],
  LAB: ["lab", "laboratory", "labs"],
  RAD: ["rad", "radiology", "x-ray", "xray", "imaging", "ct", "mri"],
  CLINICAL_AUDIT: ["clinical audit", "audit", "clinical"],
  HQI: ["hqi", "quality", "quality improvement", "improvement"],
};

// Search documents for relevant content
async function searchDocuments(query: string, supabase: SupabaseClient): Promise<string> {
  try {
    // Get all documents with content
    const { data: documents, error } = await supabase
      .from("documents")
      .select("name, content, description, category")
      .not("content", "is", null);

    if (error || !documents || documents.length === 0) {
      console.log("No documents found or error:", error);
      return "";
    }

    const queryLower = query.toLowerCase();
    
    // Check if query matches any category keywords
    let matchedCategory: string | null = null;
    for (const [category, keywords] of Object.entries(CATEGORY_KEYWORDS)) {
      for (const keyword of keywords) {
        if (queryLower.includes(keyword)) {
          matchedCategory = category;
          console.log(`Query matches category: ${category} (keyword: ${keyword})`);
          break;
        }
      }
      if (matchedCategory) break;
    }

    // Simple keyword matching - allow short words like "ED" (2 chars minimum)
    const queryWords = queryLower.split(/\s+/).filter((w: string) => w.length >= 2);
    
    const scoredDocs = (documents as Document[]).map(function(doc: Document): ScoredDocument {
      const content = (doc.content || "").toLowerCase();
      const name = (doc.name || "").toLowerCase();
      const description = (doc.description || "").toLowerCase();
      const category = (doc.category || "").toLowerCase();
      
      // Count matching keywords
      let score = 0;
      
      // High priority: if document category matches the detected category from query
      if (matchedCategory && doc.category === matchedCategory) {
        score += 10; // Strong boost for category match
        console.log(`Document "${doc.name}" matches category ${matchedCategory}`);
      }
      
      for (const word of queryWords) {
        if (content.includes(word)) score += 2;
        if (name.includes(word)) score += 3;
        if (description.includes(word)) score += 2;
        if (category.includes(word)) score += 5; // Category match in content
      }
      
      return { ...doc, score };
    });

    const relevantDocs: ScoredDocument[] = scoredDocs
      .filter(function(doc: ScoredDocument): boolean { return doc.score > 0; })
      .sort(function(a: ScoredDocument, b: ScoredDocument): number { return b.score - a.score; })
      .slice(0, 5); // Top 5 most relevant (increased from 3)

    if (relevantDocs.length === 0) {
      return "";
    }

    const context = relevantDocs
      .map(function(doc: ScoredDocument): string {
        const content = doc.content?.substring(0, 5000) || ""; // Limit content size
        const categoryLabel = doc.category ? `Category: ${doc.category}\n` : "";
        return `[Document: ${doc.name}]\n${categoryLabel}${doc.description ? `Description: ${doc.description}\n` : ""}Content:\n${content}`;
      })
      .join("\n\n---\n\n");

    console.log(`Found ${relevantDocs.length} relevant documents for query`);
    return context;
  } catch (error) {
    console.error("Error searching documents:", error);
    return "";
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const PERPLEXITY_API_KEY = Deno.env.get("PERPLEXITY_API_KEY");

    if (!PERPLEXITY_API_KEY) {
      throw new Error("PERPLEXITY_API_KEY is not configured");
    }

    // Verify user authentication
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      console.error("No authorization header provided");
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create client with user's auth context
    const supabaseClient = createClient(supabaseUrl, supabaseServiceKey, {
      global: { headers: { Authorization: authHeader } }
    });

    // Verify user token and get user
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);

    if (authError || !user) {
      console.error("Invalid authentication:", authError?.message);
      return new Response(
        JSON.stringify({ error: "Invalid authentication" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Chat request from authenticated user:", user.id);

    // Parse and validate request body
    const body = await req.json();
    const validationResult = chatRequestSchema.safeParse(body);
    
    if (!validationResult.success) {
      console.error("Validation error:", validationResult.error.errors);
      return new Response(
        JSON.stringify({ 
          error: "Invalid request", 
          details: validationResult.error.errors.map(e => e.message).join(", ") 
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    const { messages, language } = validationResult.data;

    // Language instruction for response
    const languageInstruction = language === "ar" 
      ? "\n\nIMPORTANT: You MUST respond in Arabic (العربية). All your responses should be in Arabic language."
      : "";

    // Normalize messages to ensure alternating user/assistant pattern
    // Perplexity requires messages to alternate between user and assistant
    const normalizedMessages: Array<{ role: string; content: string }> = [];
    for (const msg of messages) {
      if (msg.role === "system") continue; // Skip system messages from client
      
      const lastMsg = normalizedMessages[normalizedMessages.length - 1];
      // If same role as previous, merge or skip
      if (lastMsg && lastMsg.role === msg.role) {
        // Merge consecutive same-role messages
        lastMsg.content = lastMsg.content + "\n\n" + msg.content;
      } else {
        normalizedMessages.push({ role: msg.role, content: msg.content });
      }
    }

    // Ensure we start with a user message
    if (normalizedMessages.length > 0 && normalizedMessages[0].role !== "user") {
      normalizedMessages.shift();
    }

    // Use service role client for document search (to access all documents)
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get the last user message for document search
    const lastUserMessage = [...normalizedMessages].reverse().find((m) => m.role === "user");
    const documentContext = lastUserMessage 
      ? await searchDocuments(lastUserMessage.content, supabase)
      : "";

    // Build system prompt based on whether we have local documents
    let systemPrompt: string;
    
    if (documentContext) {
      systemPrompt = `You are an AI assistant for Taif Children's Hospital Emergency Room Department.
You help healthcare workers analyze ER performance data, patient statistics, and department reports.

CRITICAL INSTRUCTION: The user has uploaded hospital documents with REAL DATA. You MUST use ONLY the data from these documents to answer questions. DO NOT search the web or cite external sources. The uploaded documents contain the actual hospital data the user wants analyzed.

UPLOADED HOSPITAL DATA:
${documentContext}

When answering:
- Analyze the ACTUAL DATA from the uploaded documents above
- Extract statistics, patient counts, dates, and metrics from the data
- Provide specific numbers and insights from the uploaded data
- If asked about data not in the documents, say "This specific information is not in the uploaded documents"
- DO NOT reference web search results or external articles
- The data above contains REAL patient records - use them${languageInstruction}`;
    } else {
      systemPrompt = `You are an AI assistant for Taif Children's Hospital Emergency Room Department.
You help healthcare workers analyze ER performance data, patient statistics, and department reports.
Be concise, accurate, and helpful. When asked about specific data, explain that no documents have been uploaded yet.
Suggest the user upload relevant Excel files or reports to get data analysis.${languageInstruction}`;
    }

    console.log("Sending", normalizedMessages.length, "messages to Perplexity");

    const response = await fetch("https://api.perplexity.ai/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${PERPLEXITY_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "sonar",
        messages: [
          { role: "system", content: systemPrompt },
          ...normalizedMessages,
        ],
        stream: true,
        // Disable web search when we have local documents
        ...(documentContext ? { search_context_size: "none" } : {}),
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Perplexity API error:", response.status, errorText);
      
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded" }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      
      return new Response(JSON.stringify({ error: "AI service error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (error) {
    console.error("Chat error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
